<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<fieldset>
	<input type="text" value="" name="s" id="s" placeholder="<?php _e('Search', 'themeva' ); ?>" />
	<input type="submit" id="searchsubmit" value="&#xf002;" />
	</fieldset>
</form>