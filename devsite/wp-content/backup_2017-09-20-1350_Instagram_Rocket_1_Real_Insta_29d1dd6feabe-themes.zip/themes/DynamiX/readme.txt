Tersus - Responsive Wordpress Theme
_____________________

:: Installation
_____________________

Please ensure the theme is installed correctly by unzipping the main .zip file downloaded from ThemeForest. 

Now re-zip (compress) JUST the Tersus folder. ( DO NOT include the Tersus-WordPress, PSD, Licensing or Demo-XML Folders.)

Failing to do so will result in the Theme not functioning correctly. 

Please see this page for more information on correctly installing themes from ThemeForest. 
http://wiki.envato.com/buying/support-buying/solving-broken-theme-issues/
_____________________

:: Documentation
_____________________

Documentation can be found within the Wordpress Admin -> Theme Options -> Documentation. 


