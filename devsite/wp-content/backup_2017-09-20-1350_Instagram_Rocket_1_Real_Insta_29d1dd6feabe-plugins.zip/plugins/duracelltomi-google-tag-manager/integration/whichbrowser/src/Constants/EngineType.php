<?php


namespace WhichBrowser\Constants;

class EngineType
{
    const TRIDENT = 1;
    const PRESTO = 2;
    const CHROMIUM = 4;
    const GECKO = 8;
    const WEBKIT = 16;
    const V8 = 32;
}
