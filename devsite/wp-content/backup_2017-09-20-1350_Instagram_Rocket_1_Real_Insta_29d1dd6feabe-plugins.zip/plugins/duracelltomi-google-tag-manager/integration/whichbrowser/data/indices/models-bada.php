<?php

namespace WhichBrowser\Data;

DeviceModels::$BADA_INDEX = array (
  '@GT' => 
  array (
    0 => 'GT- ?S52(50|53)!',
    1 => 'GT-S53(30|33)!',
    2 => 'GT-S5380!',
    3 => 'GT-S57(50|53)!',
    4 => 'GT-S57(80)!',
    5 => 'GT-S72(30|33)!',
    6 => 'GT-S7250!',
    7 => 'GT-S8500!',
    8 => 'GT- ?S8530!',
    9 => 'GT- ?S8600!',
  ),
  '@SC' => 
  array (
    0 => 'SCH-F859!',
  ),
  '@SH' => 
  array (
    0 => 'SHW-M410',
  ),
);
