	jQuery(document).ready(function(jQuery)
		{	

					jQuery('.pricingtable_row_bg_even, .pricingtable_row_bg_odd, .pricingtable_cell_header_bg_color, .pricingtable_cell_signup_bg_color, .pricingtable_cell_price_bg_color, .pricingtable_cell_signup_button_bg_color').wpColorPicker();

		});